# Penguins findings

- 344 penguins across three species; 342 have both mass and flipper measurements.
- Mean body mass: Adelie 3701 g, Chinstrap 3733 g, Gentoo 5076 g.
- Pooled Pearson correlation (flipper length vs mass): 0.871.
- Within-species correlations: Adelie 0.468, Chinstrap 0.642, Gentoo 0.703.

The pooled association is stronger than some within-species associations. Species mix matters;
a pooled correlation is not a causal effect. Samples come from particular islands and years,
not a random sample of every penguin population. No claim of statistical significance is made.
Missing sex values are not imputed, and do not exclude otherwise usable mass/flipper pairs.
The counts in species_statistics.csv are per measurement, not an invented common denominator.

![Penguins dashboard](penguins_dashboard.png)
